<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>Display your name on the screen using PHP.</h3>
    <?php
    echo "My name is <b> Anusheh Younas</b>";
    print "My name is <h3>Anusheh Younas </h3>";

    ?>
</body>
</html>