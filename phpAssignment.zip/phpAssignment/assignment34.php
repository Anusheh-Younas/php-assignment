<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>You need to write a program in PHP using for...each 
loop to remove specific elements by value from an array 
using PHP program.
Hint:
• Take an array with list of month names.
• Take a variable with the name of value to be deleted</h3>
<?php
$array=(
    "January", "February","March","April","May","June","July","August",
    "September","October","November","December"
    )
foreach ($array as $value){
    echo "$value <br>";
}
$valueToDelete="June";
$array=array_diff($array, [$valueToDelete]);
print_r ($array);
?>
</body>
</html>